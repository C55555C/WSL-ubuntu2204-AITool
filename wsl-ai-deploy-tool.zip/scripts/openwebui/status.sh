#!/bin/bash
source ../common.sh
clear
info "OPENWEBUI - Status"
echo "执行 OPENWEBUI - Status 的操作逻辑..."

read -p "按回车键返回菜单..." _
bash ../../wsl-ultimate-deploy.sh
