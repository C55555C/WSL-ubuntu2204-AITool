#!/bin/bash
source ../common.sh
clear
info "OLLAMA - Install"
echo "执行 OLLAMA - Install 的操作逻辑..."

read -p "按回车键返回菜单..." _
bash ../../wsl-ultimate-deploy.sh
