#!/bin/bash
source ../common.sh
clear
info "OLLAMA - Status"
echo "执行 OLLAMA - Status 的操作逻辑..."

read -p "按回车键返回菜单..." _
bash ../../wsl-ultimate-deploy.sh
