#!/bin/bash
source ../common.sh
clear
info "ANYTHINGLLM - Config"
echo "执行 ANYTHINGLLM - Config 的操作逻辑..."

read -p "按回车键返回菜单..." _
bash ../../wsl-ultimate-deploy.sh
