#!/bin/bash
source ../common.sh
clear
info "TAILSCALE - Login"
echo "执行 TAILSCALE - Login 的操作逻辑..."

read -p "按回车键返回菜单..." _
bash ../../wsl-ultimate-deploy.sh
